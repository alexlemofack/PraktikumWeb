package de.hwg_lu.liligerbean;

public class LiligerBean {

	public LiligerBean() {
		// TODO Auto-generated constructor stub
	}

}
