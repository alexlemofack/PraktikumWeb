package de.hwg_lu.bwi.jdbc;

import de.hwg_lu.bw4s.beans.BenutzerBean; // Importieren der BenutzerBean-Klasse

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class PostgreSQLAccessBib {
    private String dbDrivername;
    private String dbURL;
    private String dbUser;
    private String dbPassword;
    private String dbSchema;

    public PostgreSQLAccessBib() {
        // Standardkonstruktor
        setDBParms();
    }

    public void setDBParms() {
        dbDrivername = "org.postgresql.Driver";
        dbURL = "jdbc:postgresql://143.93.200.243:5435/BWUEBDB";
        dbUser = "user1";
        dbPassword = "pgusers";
        //		dbURL        = "jdbc:postgresql://localhost:5432/BWUEBDB";
        //		dbUser       = "postgres";
        //		dbPassword   = "pgadmin";
        dbSchema = "bwi420_637177"; // Hier Matrikelnummer eintragen
    }

    // Methode zum Einfügen eines neuen Benutzers in die Datenbank
    public boolean insertBenutzer(BenutzerBean benutzer) {
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(
                     "INSERT INTO " + dbSchema + ".Benutzer (vorname, nachname, geschlecht, email, geburtsdatum, telefonnummer) " +
                             "VALUES (?, ?, ?, ?, ?, ?)")) {
            pstmt.setString(1, benutzer.getVorname());
            pstmt.setString(2, benutzer.getNachname());
            pstmt.setString(3, benutzer.getGeschlecht());
            pstmt.setString(4, benutzer.getEmail());
            pstmt.setString(5, benutzer.getGeburtsdatum());
            pstmt.setString(6, benutzer.getTelefonnummer());
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Methode zum Herstellen der Verbindung zur Datenbank
    private Connection getConnection() throws SQLException {
        try {
            Class.forName(dbDrivername);
            return DriverManager.getConnection(dbURL, dbUser, dbPassword);
        } catch (ClassNotFoundException e) {
            throw new SQLException("JDBC-Treiber konnte nicht gefunden werden.", e);
        }
    }

 // Methode zum Erstellen der Datenbanktabelle "Benutzer"
    public void createBenutzerTable() {
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement()) {
            String sqlCreateTable = "CREATE TABLE IF NOT EXISTS " + dbSchema + ".Benutzer (" +
                    "id SERIAL PRIMARY KEY," +
                    "vorname VARCHAR(50) NOT NULL," +
                    "nachname VARCHAR(50) NOT NULL," +
                    "geschlecht VARCHAR(10) NOT NULL," +
                    "email VARCHAR(100) NOT NULL," +
                    "geburtsdatum DATE NOT NULL," +
                    "telefonnummer VARCHAR(20) NOT NULL" +
                    "login_attempts INTEGER NOT NULL DEFAULT 0" +
                    ");";
            stmt.execute(sqlCreateTable);

            // Überprüfen, ob die Tabelle bereits Daten enthält
            String sqlCount = "SELECT COUNT(*) FROM " + dbSchema + ".Benutzer;";
            int count = 0;
            try (ResultSet rs = stmt.executeQuery(sqlCount)) {
                if (rs.next()) {
                    count = rs.getInt(1);
                }
            }

            // Falls die Tabelle Daten enthält, die ID der nächsten Zeile berechnen
            if (count > 0) {
                // Eine vierstellige ID generieren (z.B. 0001, 0002, ...)
                String sqlUpdateID = "ALTER SEQUENCE " + dbSchema + ".Benutzer_id_seq RESTART WITH " + String.format("%04d", count + 1) + ";";
                stmt.execute(sqlUpdateID);
            }

            System.out.println("Tabelle 'Benutzer' wurde erfolgreich erstellt.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
