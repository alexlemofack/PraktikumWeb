package de.hwg_lu.bwi.jdbc;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.ServletException;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/MeinServlet")
public class MeinServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Verarbeitung der GET-Anfrage
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Mein Servlet - GET-Anfrage</title>");
        out.println("</head>");
        out.println("<body>");
        out.println("<h1>Willkommen im MeinServlet - GET</h1>");
        out.println("<p>Dies ist eine GET-Anfrage an das Servlet.</p>");
        out.println("</body>");
        out.println("</html>");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Verarbeitung der POST-Anfrage
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        // E-Mail-Adresse aus dem Formular erhalten
        String email = request.getParameter("email");
        String errorMessage = null;

        // Überprüfen, ob die E-Mail-Adresse das Zeichen '@' enthält
        if (email == null || !email.contains("@")) {
            errorMessage = "Ungültige E-Mail-Adresse. Bitte geben Sie eine gültige E-Mail-Adresse ein.";
        }

        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Mein Servlet - POST-Anfrage</title>");
        out.println("</head>");
        out.println("<body>");
        out.println("<h1>Willkommen im MeinServlet - POST</h1>");
        
        // Fehlermeldung anzeigen, falls vorhanden
        if (errorMessage != null) {
            out.println("<p style='color: red;'>" + errorMessage + "</p>");
        }
        
        out.println("<p>Dies ist eine POST-Anfrage an das Servlet.</p>");
        out.println("</body>");
        out.println("</html>");
    }
}
