package de.hwg_lu.bw4s.beans;

public class Artikel {
	int anr;
	String aname;
	double preis;
		
	public int getAnr() {
		return anr;
	}
	public void setAnr(int anr) {
		this.anr = anr;
	}
	public String getAname() {
		return aname;
	}
	public void setAname(String aname) {
		this.aname = aname;
	}
	public double getPreis() {
		return preis;
	}
	public void setPreis(double preis) {
		this.preis = preis;
	}
	
}
